(() => {
"use strict";
const STORAGE_KEY = "sklekKing.local.v1";
const MAX_COUNT = 1000000;
const MAX_ENTRIES = 10000;
const DEFAULTS = {
  version: 1,
  entries: {},
  goals: { daily: 100, weekly: 500, monthly: 2000 },
  celebrations: [],
  settings: {
    accent: "#39e75f", background: "#050705", text: "#f4f7f4", button: "#1c9b43",
    chartStyle: "bars", photoOpacity: 6, fontSize: 16,
    animations: true, sound: true, vibration: true, shake: true
  }
};
const $ = (id) => document.getElementById(id);
let state = loadState();
let selectedDate = dateKey(new Date());
let activeChart = "day";
let editOriginal = null;
let currentGoalEdit = null;
let celebrationQueue = [];
let toastTimer = null;
let deferredInstallPrompt = null;

function clone(obj){ return JSON.parse(JSON.stringify(obj)); }
function isDateKey(s){
  if(typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y,m,d] = s.split("-").map(Number);
  const dt = new Date(y,m-1,d);
  return dt.getFullYear()===y && dt.getMonth()===m-1 && dt.getDate()===d;
}
function dateKey(d){
  const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),day=String(d.getDate()).padStart(2,"0");
  return `${y}-${m}-${day}`;
}
function fromKey(k){const [y,m,d]=k.split("-").map(Number);return new Date(y,m-1,d);}
function addDays(d,n){const x=new Date(d.getFullYear(),d.getMonth(),d.getDate());x.setDate(x.getDate()+n);return x;}
function fmtDate(k,opts={day:"numeric",month:"short",year:"numeric"}){
  return new Intl.DateTimeFormat("sr-Latn-RS",opts).format(fromKey(k));
}
function mondayKey(k){
  const d=fromKey(k); const offset=(d.getDay()+6)%7; return dateKey(addDays(d,-offset));
}
function monthKey(k){return k.slice(0,7);}
function periodToken(type,k){
  if(type==="daily") return `daily:${k}`;
  if(type==="weekly") return `weekly:${mondayKey(k)}`;
  return `monthly:${monthKey(k)}`;
}
function periodBounds(type,k){
  if(type==="daily") return [k,k];
  if(type==="weekly"){const s=mondayKey(k);return [s,dateKey(addDays(fromKey(s),6))];}
  const [y,m]=monthKey(k).split("-").map(Number);
  return [`${y}-${String(m).padStart(2,"0")}-01`,dateKey(new Date(y,m,0))];
}
function sumFor(entries,type,k){
  const [start,end]=periodBounds(type,k); let total=0;
  for(const [d,v] of Object.entries(entries)){
    if(d>=start && d<=end) total+=v;
  }
  return total;
}
function validColor(v, fallback){
  return typeof v==="string" && /^#[0-9a-fA-F]{6}$/.test(v) ? v : fallback;
}
function loadState(){
  try{
    const raw=localStorage.getItem(STORAGE_KEY);
    if(!raw) return clone(DEFAULTS);
    const parsed=JSON.parse(raw);
    const out=clone(DEFAULTS);
    if(parsed && typeof parsed==="object"){
      if(parsed.entries && typeof parsed.entries==="object" && !Array.isArray(parsed.entries)){
        for(const [k,v] of Object.entries(parsed.entries).slice(0,MAX_ENTRIES)){
          if(isDateKey(k) && Number.isSafeInteger(v) && v>0 && v<=MAX_COUNT) out.entries[k]=v;
        }
      }
      if(parsed.goals && typeof parsed.goals==="object"){
        for(const k of ["daily","weekly","monthly"]){
          const v=parsed.goals[k]; if(Number.isSafeInteger(v) && v>=1 && v<=100000) out.goals[k]=v;
        }
      }
      if(Array.isArray(parsed.celebrations)){
        out.celebrations=parsed.celebrations.filter(x=>typeof x==="string" && /^(daily:\d{4}-\d{2}-\d{2}|weekly:\d{4}-\d{2}-\d{2}|monthly:\d{4}-\d{2})$/.test(x)).slice(0,50000);
      }
      if(parsed.settings && typeof parsed.settings==="object"){
        const s=parsed.settings, d=out.settings;
        d.accent=validColor(s.accent,d.accent); d.background=["#050705","#15191b","#252b30"].includes(s.background)?s.background:d.background;
        d.text=validColor(s.text,d.text); d.button=validColor(s.button,d.button);
        d.chartStyle=["bars","line"].includes(s.chartStyle)?s.chartStyle:d.chartStyle;
        d.photoOpacity=Number.isInteger(s.photoOpacity)?Math.max(0,Math.min(8,s.photoOpacity)):d.photoOpacity;
        d.fontSize=Number.isInteger(s.fontSize)?Math.max(14,Math.min(20,s.fontSize)):d.fontSize;
        for(const k of ["animations","sound","vibration","shake"]) if(typeof s[k]==="boolean") d[k]=s[k];
      }
    }
    return out;
  }catch(e){return clone(DEFAULTS);}
}
function saveState(){
  try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}
  catch(e){showToast("Nije moguće sačuvati podatke. Izvezi rezervnu kopiju i oslobodi prostor.");}
}
function showToast(message){
  const t=$("toast"); t.textContent=message; t.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove("show"),2600);
}
function total(entries=state.entries){return Object.values(entries).reduce((a,b)=>a+b,0);}
function activeDates(){return Object.keys(state.entries).filter(k=>state.entries[k]>0).sort();}
function currentStreak(){
  const today=dateKey(new Date()); let cursor=fromKey(today);
  if(!state.entries[today]){cursor=addDays(cursor,-1);if(!state.entries[dateKey(cursor)])return 0;}
  let n=0;
  while(state.entries[dateKey(cursor)]>0 && n<MAX_ENTRIES){n++;cursor=addDays(cursor,-1);}
  return n;
}
function bestPeriod(type){
  const map=new Map();
  for(const [d,v] of Object.entries(state.entries)){
    const key=type==="day"?d:(type==="week"?mondayKey(d):monthKey(d));
    map.set(key,(map.get(key)||0)+v);
  }
  let bestKey=null,best=0;
  for(const [k,v] of map){if(v>best){best=v;bestKey=k;}}
  return {key:bestKey,value:best};
}
function labelPeriod(type,key){
  if(!key)return "Još nema unosa";
  if(type==="day")return fmtDate(key);
  if(type==="week"){const end=dateKey(addDays(fromKey(key),6));return `${fmtDate(key,{day:"numeric",month:"short"})} – ${fmtDate(end,{day:"numeric",month:"short",year:"numeric"})}`;}
  const [y,m]=key.split("-").map(Number);
  return new Intl.DateTimeFormat("sr-Latn-RS",{month:"long",year:"numeric"}).format(new Date(y,m-1,1));
}
function renderHome(){
  const today=dateKey(new Date()), now=new Date();
  $("totalAll").textContent=total().toLocaleString("sr-Latn-RS");
  $("totalToday").textContent=(state.entries[today]||0).toLocaleString("sr-Latn-RS");
  $("totalMonth").textContent=sumFor(state.entries,"monthly",today).toLocaleString("sr-Latn-RS");
  $("todayDateLabel").textContent=fmtDate(today,{weekday:"long",day:"numeric",month:"long"});
  $("monthLabel").textContent=new Intl.DateTimeFormat("sr-Latn-RS",{month:"long",year:"numeric"}).format(now);
  $("entryDate").value=selectedDate;
  const labels={
    daily:"Danas",
    weekly:`${fmtDate(mondayKey(today),{day:"numeric",month:"short"})} – ${fmtDate(dateKey(addDays(fromKey(mondayKey(today)),6)),{day:"numeric",month:"short"})}`,
    monthly:new Intl.DateTimeFormat("sr-Latn-RS",{month:"long"}).format(now)
  };
  for(const type of ["daily","weekly","monthly"]){
    const value=sumFor(state.entries,type,today),goal=state.goals[type],pct=Math.round(value/goal*100);
    $(type+"Done").textContent=value.toLocaleString("sr-Latn-RS");
    $(type+"Target").textContent=goal.toLocaleString("sr-Latn-RS");
    $(type+"Bar").style.width=Math.min(100,pct)+"%";
    $(type+"Percent").textContent=pct+"%";
    $(type+"Period").textContent=labels[type];
  }
  const best=bestPeriod("day");
  $("homeBestDay").textContent=best.value?`${best.value.toLocaleString("sr-Latn-RS")} • ${fmtDate(best.key,{day:"numeric",month:"short"})}`:"—";
  $("homeStreak").textContent=currentStreak()+" dana";
  $("entryHint").textContent=selectedDate===today?"Rezultat se dodaje današnjem zbiru.":"Unosiš rezultat za "+fmtDate(selectedDate)+". Propušteni dani su dobrodošli.";
}
function renderDiary(){
  const list=$("diaryList"); list.replaceChildren();
  const dates=activeDates().sort((a,b)=>b.localeCompare(a));
  $("diaryDays").textContent=dates.length.toLocaleString("sr-Latn-RS");
  $("diaryEmpty").hidden=dates.length!==0;
  for(const d of dates){
    const item=document.createElement("article");item.className="diary-item";
    const info=document.createElement("div");
    const date=document.createElement("div");date.className="diary-date";date.textContent=fmtDate(d);
    const weekday=document.createElement("div");weekday.className="diary-weekday";weekday.textContent=new Intl.DateTimeFormat("sr-Latn-RS",{weekday:"long"}).format(fromKey(d));
    info.append(date,weekday);
    const count=document.createElement("div");count.className="diary-count";count.textContent=state.entries[d].toLocaleString("sr-Latn-RS")+" ";
    const small=document.createElement("small");small.textContent="sklekova";count.append(small);
    const actions=document.createElement("div");actions.className="diary-actions";
    const edit=document.createElement("button");edit.type="button";edit.textContent="Uredi";edit.setAttribute("aria-label","Uredi "+fmtDate(d));edit.addEventListener("click",()=>openEdit(d));
    const del=document.createElement("button");del.type="button";del.className="delete-entry";del.textContent="Obriši";del.setAttribute("aria-label","Obriši "+fmtDate(d));del.addEventListener("click",()=>deleteEntry(d));
    actions.append(edit,del);item.append(info,count,actions);list.append(item);
  }
}
function renderStats(){
  const today=dateKey(new Date());
  $("statsToday").textContent=(state.entries[today]||0).toLocaleString("sr-Latn-RS");
  $("statsWeek").textContent=sumFor(state.entries,"weekly",today).toLocaleString("sr-Latn-RS");
  $("statsMonth").textContent=sumFor(state.entries,"monthly",today).toLocaleString("sr-Latn-RS");
  const bd=bestPeriod("day"),bw=bestPeriod("week"),bm=bestPeriod("month");
  $("bestDayValue").textContent=bd.value.toLocaleString("sr-Latn-RS");$("bestDayDate").textContent=labelPeriod("day",bd.key);
  $("bestWeekValue").textContent=bw.value.toLocaleString("sr-Latn-RS");$("bestWeekDate").textContent=labelPeriod("week",bw.key);
  $("bestMonthValue").textContent=bm.value.toLocaleString("sr-Latn-RS");$("bestMonthDate").textContent=labelPeriod("month",bm.key);
  const streak=currentStreak();$("streakValue").textContent=streak+" dana";$("streakCaption").textContent=streak?"Niz se računa do danas ili juče.":"Nema aktivnog niza trenutno.";
  renderChart();
}
function svgEl(tag,attrs={},textValue=null){
  const el=document.createElementNS("http://www.w3.org/2000/svg",tag);
  for(const [k,v] of Object.entries(attrs))el.setAttribute(k,String(v));
  if(textValue!==null)el.textContent=String(textValue);
  return el;
}
function chartData(){
  const now=new Date(),today=dateKey(now),data=[];
  if(activeChart==="day"){
    for(let i=6;i>=0;i--){const k=dateKey(addDays(now,-i));data.push({label:new Intl.DateTimeFormat("sr-Latn-RS",{weekday:"short"}).format(fromKey(k)),value:state.entries[k]||0});}
    $("chartEyebrow").textContent="POSLEDNJIH 7 DANA";$("chartTitle").textContent="Dnevni učinak";$("yearSelectWrap").hidden=true;
  }else if(activeChart==="week"){
    const thisMon=fromKey(mondayKey(today));
    for(let i=7;i>=0;i--){const s=dateKey(addDays(thisMon,-7*i));data.push({label:fmtDate(s,{day:"numeric",month:"short"}),value:sumFor(state.entries,"weekly",s)});}
    $("chartEyebrow").textContent="POSLEDNJIH 8 NEDELJA";$("chartTitle").textContent="Nedeljni učinak";$("yearSelectWrap").hidden=true;
  }else if(activeChart==="month"){
    for(let i=11;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);const k=dateKey(d);data.push({label:new Intl.DateTimeFormat("sr-Latn-RS",{month:"short"}).format(d),value:sumFor(state.entries,"monthly",k)});}
    $("chartEyebrow").textContent="POSLEDNJIH 12 MESECI";$("chartTitle").textContent="Mesečni učinak";$("yearSelectWrap").hidden=true;
  }else{
    const year=Number($("statsYear").value)||now.getFullYear();
    for(let m=0;m<12;m++){const d=new Date(year,m,1);data.push({label:new Intl.DateTimeFormat("sr-Latn-RS",{month:"short"}).format(d),value:sumFor(state.entries,"monthly",dateKey(d))});}
    $("chartEyebrow").textContent="GODIŠNJI PREGLED";$("chartTitle").textContent="Učinak po mesecima • "+year;$("yearSelectWrap").hidden=false;
  }
  return data;
}
function renderChart(){
  const data=chartData(),area=$("chartArea");area.replaceChildren();
  const totalValue=data.reduce((a,x)=>a+x.value,0);
  $("chartTotal").textContent=totalValue.toLocaleString("sr-Latn-RS")+" ukupno";
  const svg=svgEl("svg",{viewBox:"0 0 360 205",role:"presentation","aria-hidden":"true"});
  const left=31,right=350,top=14,bottom=158,height=bottom-top,width=right-left;
  const max=Math.max(10,...data.map(x=>x.value));
  for(let i=0;i<=3;i++){
    const y=bottom-(height*i/3);
    svg.append(svgEl("line",{x1:left,y1:y,x2:right,y2:y,stroke:"rgba(255,255,255,.11)","stroke-width":1}));
    svg.append(svgEl("text",{x:25,y:y+3,"text-anchor":"end",fill:"#7f8c82","font-size":8},Math.round(max*i/3).toLocaleString("sr-Latn-RS")));
  }
  const step=width/data.length;
  if(state.settings.chartStyle==="line"){
    const pts=data.map((d,i)=>[left+step*(i+.5),bottom-(d.value/max)*(height*.88)]);
    const path=pts.map((p,i)=>(i?"L":"M")+p[0]+","+p[1]).join(" ");
    svg.append(svgEl("path",{d:path,fill:"none",stroke:"var(--accent)","stroke-width":3,"stroke-linecap":"round","stroke-linejoin":"round"}));
    pts.forEach((p,i)=>{svg.append(svgEl("circle",{cx:p[0],cy:p[1],r:4,fill:"var(--accent)",stroke:"#071009","stroke-width":2}));});
  }else{
    data.forEach((d,i)=>{
      const barW=Math.max(8,Math.min(25,step*.54)),barH=(d.value/max)*(height*.88),x=left+step*i+(step-barW)/2,y=bottom-barH;
      svg.append(svgEl("rect",{x,y,width:barW,height:Math.max(2,barH),rx:4,fill:"var(--accent)",opacity:d.value?0.9:0.2}));
    });
  }
  data.forEach((d,i)=>{
    const x=left+step*(i+.5);
    svg.append(svgEl("text",{x,y:177,"text-anchor":"middle",fill:"#a0aaa3","font-size":data.length>9?7.5:9},d.label));
  });
  area.append(svg);
  $("chartCaption").textContent=activeChart==="year"?"Svaki stubić predstavlja jedan mesec iz izabrane godine.":"Svaki stubić predstavlja ukupan broj sklekova u periodu.";
}
function populateYears(){
  const years=new Set([new Date().getFullYear()]);
  for(const d of Object.keys(state.entries))years.add(Number(d.slice(0,4)));
  const sel=$("statsYear"),old=sel.value;sel.replaceChildren();
  [...years].sort((a,b)=>b-a).forEach(y=>{const o=document.createElement("option");o.value=String(y);o.textContent=String(y);sel.append(o);});
  if([...years].some(y=>String(y)===old))sel.value=old;
  else sel.value=String(new Date().getFullYear());
}
function renderAll(){
  renderHome();renderDiary();populateYears();renderStats();syncSettingsUI();applySettings();
}
function applySettings(){
  const s=state.settings,root=document.documentElement;
  root.style.setProperty("--accent",s.accent);root.style.setProperty("--bg",s.background);
  root.style.setProperty("--text",s.text);root.style.setProperty("--button",s.button);
  root.style.setProperty("--photo-opacity",String(s.photoOpacity/100));root.style.setProperty("--font-size",s.fontSize+"px");
  document.querySelector('meta[name="theme-color"]').setAttribute("content",s.background);
  document.querySelectorAll(".swatch").forEach(b=>b.classList.toggle("selected",b.dataset.accent===s.accent));
}
function syncSettingsUI(){
  const s=state.settings;
  $("accentPicker").value=s.accent;$("backgroundSelect").value=s.background;$("textPicker").value=s.text;$("buttonPicker").value=s.button;
  $("chartStyle").value=s.chartStyle;$("photoOpacity").value=s.photoOpacity;$("fontSize").value=s.fontSize;
  $("photoOpacityLabel").textContent=s.photoOpacity+"% — "+(s.photoOpacity===0?"isključeno":"diskretna pozadina");
  $("fontSizeLabel").textContent=s.fontSize+" px";
  $("toggleAnimations").checked=s.animations;$("toggleSound").checked=s.sound;$("toggleVibration").checked=s.vibration;$("toggleShake").checked=s.shake;
}
function persistSettings(){saveState();applySettings();renderStats();}
function setView(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id==="view-"+name));
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  if(name==="stats")renderStats();
  window.scrollTo({top:0,behavior:"smooth"});
}
function addReps(amount){
  if(!Number.isSafeInteger(amount)||amount<1||amount>MAX_COUNT){showToast("Unesi broj od 1 do 1.000.000.");return;}
  const prev=clone(state.entries),next=clone(state.entries);
  const old=next[selectedDate]||0;
  if(!old && Object.keys(next).length>=MAX_ENTRIES){showToast("Dostignut je najveći broj datuma u evidenciji. Izvezi rezervnu kopiju.");return;}
  if(old+amount>MAX_COUNT){showToast("Za ovaj datum je dostignut najveći dozvoljeni zbir.");return;}
  next[selectedDate]=old+amount;
  applyEntryChange(prev,next,selectedDate);
  showToast("Dodato "+amount.toLocaleString("sr-Latn-RS")+" sklekova.");
}
function applyEntryChange(previous,next,changedDate){
  state.entries=next;
  const today=dateKey(new Date()),newWins=[];
  const checks=[
    {type:"daily",relevant:changedDate===today},
    {type:"weekly",relevant:mondayKey(changedDate)===mondayKey(today)},
    {type:"monthly",relevant:monthKey(changedDate)===monthKey(today)}
  ];
  for(const c of checks){
    if(!c.relevant)continue;
    const before=sumFor(previous,c.type,today),after=sumFor(next,c.type,today),goal=state.goals[c.type],token=periodToken(c.type,today);
    if(before<goal && after>=goal && !state.celebrations.includes(token)){
      state.celebrations.push(token);newWins.push(c.type);
    }
  }
  saveState();renderAll();
  if(newWins.length){celebrationQueue.push(...newWins);showNextCelebration();}
}
function openEdit(d){
  editOriginal=d;$("editOriginalDate").value=d;$("editDate").value=d;$("editCount").value=state.entries[d]||1;
  $("editDialog").showModal();
}
function deleteEntry(d){
  if(!window.confirm("Obrisati rezultat za "+fmtDate(d)+"?"))return;
  const next=clone(state.entries);delete next[d];state.entries=next;saveState();renderAll();showToast("Rezultat je obrisan.");
}
function saveEdit(event){
  event.preventDefault();
  const old=$("editOriginalDate").value,newDate=$("editDate").value,count=Number($("editCount").value);
  if(!isDateKey(newDate)||!Number.isSafeInteger(count)||count<1||count>MAX_COUNT){showToast("Proveri datum i broj sklekova.");return;}
  const prev=clone(state.entries),next=clone(state.entries);
  delete next[old];
  if(newDate!==old && next[newDate]){
    if(!window.confirm("Za izabrani datum već postoji "+next[newDate]+" sklekova. Spojiti rezultate?"))return;
    if(next[newDate]+count>MAX_COUNT){showToast("Zbir za taj datum bi bio prevelik.");return;}
    next[newDate]+=count;
  }else next[newDate]=count;
  $("editDialog").close();applyEntryChange(prev,next,newDate);showToast("Izmene su sačuvane.");
}
function editGoal(type){
  currentGoalEdit=type;$("goalEditor").hidden=false;
  $("goalEditorLabel").textContent="Novi "+(type==="daily"?"dnevni":type==="weekly"?"nedeljni":"mesečni")+" cilj";
  $("goalEditorInput").value=state.goals[type];$("goalEditorInput").focus();
}
function saveGoal(){
  const v=Number($("goalEditorInput").value);
  if(!Number.isSafeInteger(v)||v<1||v>100000){showToast("Cilj mora biti broj od 1 do 100.000.");return;}
  state.goals[currentGoalEdit]=v;saveState();$("goalEditor").hidden=true;renderHome();showToast("Cilj je sačuvan.");
}
function closeGoal(){ $("goalEditor").hidden=true;currentGoalEdit=null; }
function createJingle(){
  if(!state.settings.sound)return;
  const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;
  try{
    const ctx=new Ctx();const start=ctx.currentTime;
    const master=ctx.createGain();master.gain.setValueAtTime(0.0001,start);master.gain.exponentialRampToValueAtTime(.24,start+.06);master.gain.exponentialRampToValueAtTime(.0001,start+3.05);master.connect(ctx.destination);
    const notes=[523.25,659.25,783.99,1046.5,783.99,1046.5,1318.51];
    notes.forEach((freq,i)=>{
      const t=start+i*.36,osc=ctx.createOscillator(),gain=ctx.createGain();
      osc.type="sawtooth";osc.frequency.setValueAtTime(freq,t);
      gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.24,t+.025);gain.gain.exponentialRampToValueAtTime(.0001,t+.31);
      osc.connect(gain);gain.connect(master);osc.start(t);osc.stop(t+.33);
    });
    [0,.72,1.44,2.16].forEach(t0=>{
      const osc=ctx.createOscillator(),g=ctx.createGain(),t=start+t0;
      osc.type="sine";osc.frequency.setValueAtTime(115,t);osc.frequency.exponentialRampToValueAtTime(48,t+.16);
      g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.45,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+.2);
      osc.connect(g);g.connect(master);osc.start(t);osc.stop(t+.21);
    });
    setTimeout(()=>ctx.close().catch(()=>{}),3600);
  }catch(e){}
}
const celebrationInfo={
  daily:{title:"DNEVNI CILJ OSTVAREN!",message:"Zeleno svetlo! Danas si odradio posao.",kind:"DNEVNA POBEDA",kicker:"SVAKA ČAST!"},
  weekly:{title:"NEDELJNI CILJ OSTVAREN!",message:"Velika nedelja, velika forma. Samo nastavi!",kind:"NEDELJNA POBEDA",kicker:"DOMINACIJA!"},
  monthly:{title:"MESEČNI CILJ OSTVAREN!",message:"Ovo je kraljevski rezultat. Mesec je tvoj!",kind:"ZLATNA POBEDA",kicker:"KRALJ MESECA!"}
};
function showNextCelebration(){
  if(!celebrationQueue.length)return;
  const type=celebrationQueue.shift(),info=celebrationInfo[type],overlay=$("celebrationOverlay"),card=$("celebrationCard");
  card.dataset.kind=type;card.className="celebration-card";
  if(state.settings.animations)card.classList.add("anim-"+type);
  $("celebrationKicker").textContent=info.kicker;$("celebrationTitle").textContent=info.title;
  $("celebrationMessage").textContent=info.message;$("celebrationKind").textContent=info.kind;
  overlay.hidden=false;
  if(state.settings.shake){$("appShell").classList.remove("shake");void $("appShell").offsetWidth;$("appShell").classList.add("shake");setTimeout(()=>$("appShell").classList.remove("shake"),450);}
  if(state.settings.vibration && typeof navigator.vibrate==="function"){try{navigator.vibrate([100,45,160]);}catch(e){}}
  createJingle();
}
function closeCelebration(){
  $("celebrationOverlay").hidden=true;
  if(celebrationQueue.length)setTimeout(showNextCelebration,180);
}
function buildShareText(){
  const best=bestPeriod("day"),streak=currentStreak();
  return `Moji Sklek King rezultati 💪\nUkupno: ${total().toLocaleString("sr-Latn-RS")} sklekova\nNajbolji dan: ${best.value?best.value.toLocaleString("sr-Latn-RS")+" ("+fmtDate(best.key)+")":"još nema rekorda"}\nTrenutni niz: ${streak} dana\nAutor aplikacije: Ljubomir Ilić`;
}
async function shareResults(){
  const text=buildShareText();
  try{
    if(navigator.share){await navigator.share({title:"Moji Sklek King rezultati",text});showToast("Rezultat je spreman za deljenje.");return;}
    if(navigator.clipboard && window.isSecureContext){await navigator.clipboard.writeText(text);showToast("Rezultati su kopirani. Sada ih možeš poslati.");return;}
    const area=document.createElement("textarea");area.value=text;document.body.append(area);area.select();const ok=document.execCommand("copy");area.remove();
    showToast(ok?"Rezultati su kopirani.":"Deljenje nije podržano u ovom pregledaču.");
  }catch(e){if(e.name!=="AbortError")showToast("Deljenje trenutno nije dostupno.");}
}
function exportBackup(){
  const payload={app:"Sklek King",version:1,exportedAt:new Date().toISOString(),entries:state.entries,goals:state.goals,settings:state.settings,celebrations:state.celebrations};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download="sklek-king-rezervna-kopija-"+dateKey(new Date())+".json";document.body.append(a);a.click();a.remove();URL.revokeObjectURL(url);
  showToast("Rezervna kopija je izvezena.");
}
function validateBackup(obj){
  if(!obj || typeof obj!=="object" || obj.app!=="Sklek King" || obj.version!==1)throw new Error("Nepoznat format rezervne kopije.");
  if(!obj.entries || typeof obj.entries!=="object" || Array.isArray(obj.entries))throw new Error("Nedostaje evidencija.");
  const keys=Object.keys(obj.entries);if(keys.length>MAX_ENTRIES)throw new Error("Kopija sadrži previše datuma.");
  const entries={};
  for(const [k,v] of Object.entries(obj.entries)){
    if(!isDateKey(k)||!Number.isSafeInteger(v)||v<1||v>MAX_COUNT)throw new Error("Kopija sadrži neispravan datum ili broj.");
    entries[k]=v;
  }
  const goals={...DEFAULTS.goals};
  if(obj.goals && typeof obj.goals==="object"){
    for(const k of ["daily","weekly","monthly"]){const v=obj.goals[k];if(!Number.isSafeInteger(v)||v<1||v>100000)throw new Error("Neispravan cilj u kopiji.");goals[k]=v;}
  }
  const settings=clone(DEFAULTS.settings);
  if(obj.settings && typeof obj.settings==="object"){
    const s=obj.settings;
    settings.accent=validColor(s.accent,settings.accent);settings.background=["#050705","#15191b","#252b30"].includes(s.background)?s.background:settings.background;
    settings.text=validColor(s.text,settings.text);settings.button=validColor(s.button,settings.button);
    settings.chartStyle=["bars","line"].includes(s.chartStyle)?s.chartStyle:settings.chartStyle;
    settings.photoOpacity=Number.isInteger(s.photoOpacity)?Math.max(0,Math.min(8,s.photoOpacity)):settings.photoOpacity;
    settings.fontSize=Number.isInteger(s.fontSize)?Math.max(14,Math.min(20,s.fontSize)):settings.fontSize;
    for(const k of ["animations","sound","vibration","shake"])if(typeof s[k]==="boolean")settings[k]=s[k];
  }
  const celebrations=Array.isArray(obj.celebrations)?obj.celebrations.filter(x=>typeof x==="string"&&/^(daily:\d{4}-\d{2}-\d{2}|weekly:\d{4}-\d{2}-\d{2}|monthly:\d{4}-\d{2})$/.test(x)).slice(0,50000):[];
  return {version:1,entries,goals,settings,celebrations};
}
async function importBackup(file){
  if(!file)return;
  if(file.size>1024*1024){showToast("Fajl je prevelik. Najveća dozvoljena veličina je 1 MB.");return;}
  try{
    const parsed=JSON.parse(await file.text()),fresh=validateBackup(parsed);
    if(!window.confirm("Uvoz će zameniti postojeću evidenciju i podešavanja. Preporučujemo da prvo izvezeš trenutnu kopiju. Nastaviti?"))return;
    state=fresh;saveState();renderAll();showToast("Rezervna kopija je uspešno uvezena.");
  }catch(e){showToast(e.message||"Rezervna kopija nije ispravna.");}
  finally{$("importFile").value="";}
}
function clearAll(){
  if(!window.confirm("Obrisati sve rezultate, ciljeve, podešavanja i podatke o proslavama? Ova radnja se ne može poništiti."))return;
  state=clone(DEFAULTS);saveState();renderAll();showToast("Svi podaci su obrisani.");
}
function resetAppearance(){
  const defaults=clone(DEFAULTS.settings);
  for(const k of ["accent","background","text","button","chartStyle","photoOpacity","fontSize"])state.settings[k]=defaults[k];
  saveState();renderAll();showToast("Početni izgled je vraćen.");
}
function bind(){
  document.querySelectorAll(".nav-btn").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
  document.querySelectorAll("[data-go-view]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.goView)));
  document.querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addReps(Number(b.dataset.add))));
  $("customAddBtn").addEventListener("click",()=>{const v=Number($("customCount").value);if(!Number.isSafeInteger(v)||v<1||v>MAX_COUNT){showToast("Unesi broj od 1 do 1.000.000.");return;}addReps(v);$("customCount").value="";});
  $("customCount").addEventListener("keydown",e=>{if(e.key==="Enter")$("customAddBtn").click();});
  $("entryDate").addEventListener("change",()=>{if(isDateKey($("entryDate").value)){selectedDate=$("entryDate").value;renderHome();}});
  document.querySelectorAll("[data-edit-goal]").forEach(b=>b.addEventListener("click",()=>editGoal(b.dataset.editGoal)));
  $("saveGoalBtn").addEventListener("click",saveGoal);$("cancelGoalBtn").addEventListener("click",closeGoal);
  $("goalEditorInput").addEventListener("keydown",e=>{if(e.key==="Enter")saveGoal();});
  $("editForm").addEventListener("submit",e=>{if(e.submitter && e.submitter.id==="saveEditBtn")saveEdit(e);});
  $("editDialog").addEventListener("close",()=>{editOriginal=null;});
  document.querySelectorAll(".chart-tab").forEach(b=>b.addEventListener("click",()=>{activeChart=b.dataset.chart;document.querySelectorAll(".chart-tab").forEach(x=>x.classList.toggle("active",x===b));renderStats();}));
  $("statsYear").addEventListener("change",renderChart);
  document.querySelectorAll(".swatch").forEach(b=>b.addEventListener("click",()=>{state.settings.accent=b.dataset.accent;persistSettings();syncSettingsUI();}));
  $("accentPicker").addEventListener("input",e=>{state.settings.accent=e.target.value;persistSettings();});
  $("backgroundSelect").addEventListener("change",e=>{state.settings.background=e.target.value;persistSettings();});
  $("textPicker").addEventListener("input",e=>{state.settings.text=e.target.value;persistSettings();});
  $("buttonPicker").addEventListener("input",e=>{state.settings.button=e.target.value;persistSettings();});
  $("chartStyle").addEventListener("change",e=>{state.settings.chartStyle=e.target.value;persistSettings();});
  $("photoOpacity").addEventListener("input",e=>{state.settings.photoOpacity=Number(e.target.value);$("photoOpacityLabel").textContent=e.target.value+"% — "+(Number(e.target.value)===0?"isključeno":"diskretna pozadina");saveState();applySettings();});
  $("fontSize").addEventListener("input",e=>{state.settings.fontSize=Number(e.target.value);$("fontSizeLabel").textContent=e.target.value+" px";saveState();applySettings();});
  $("toggleAnimations").addEventListener("change",e=>{state.settings.animations=e.target.checked;persistSettings();});
  $("toggleSound").addEventListener("change",e=>{state.settings.sound=e.target.checked;persistSettings();});
  $("toggleVibration").addEventListener("change",e=>{state.settings.vibration=e.target.checked;persistSettings();});
  $("toggleShake").addEventListener("change",e=>{state.settings.shake=e.target.checked;persistSettings();});
  $("resetAppearance").addEventListener("click",resetAppearance);
  $("exportBtn").addEventListener("click",exportBackup);
  $("importFile").addEventListener("change",e=>importBackup(e.target.files[0]));
  $("clearDataBtn").addEventListener("click",clearAll);
  $("shareBtn").addEventListener("click",shareResults);
  $("closeCelebration").addEventListener("click",closeCelebration);
  $("celebrationDone").addEventListener("click",closeCelebration);
  $("celebrationOverlay").addEventListener("click",e=>{if(e.target===$("celebrationOverlay"))closeCelebration();});
  $("installBtn").addEventListener("click",async()=>{
    if(!deferredInstallPrompt)return;
    deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;$("installBtn").hidden=true;
  });
  window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstallPrompt=e;$("installBtn").hidden=false;});
  window.addEventListener("appinstalled",()=>{deferredInstallPrompt=null;$("installBtn").hidden=true;showToast("Sklek King je dodat na početni ekran.");});
}
function init(){
  bind();renderAll();
  if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")){
    navigator.serviceWorker.register("./service-worker.js",{scope:"./"}).catch(()=>{});
  }
}
init();
})();