# Sklek King — Android PWA

**Autor:** Ljubomir Ilić

Sklek King je instalabilna progresivna web-aplikacija (PWA) za Android i druge moderne pregledače. Ovo nije APK. Paket sadrži kompletnu PWA aplikaciju spremnu za postavljanje na HTTPS hosting.

## Šta je uključeno

- Brzo dodavanje +5, +10, +20 i +50, kao i proizvoljan broj sklekova.
- Evidencija po datumu, uključujući naknadne unose.
- Uređivanje, premeštanje i brisanje rezultata.
- Dnevnik sortiran od najnovijeg datuma.
- Ukupan zbir, današnji zbir i zbir tekućeg meseca.
- Dnevni, nedeljni i mesečni cilj sa brojem, procentom i trakom napretka.
- Grafikoni za poslednjih 7 dana, 8 nedelja, 12 meseci i izabranu kalendarsku godinu.
- Najbolji dan, nedelja, mesec i trenutni niz aktivnih dana.
- Izvoz i uvoz JSON rezervne kopije.
- Deljenje rezultata preko Android/Web Share API-ja kada ga pregledač podržava.
- Personalizacija boja, pozadine, grafikona, fotografije i veličine slova.
- Proslave ciljeva: dnevna zelena, nedeljna žuta, mesečna zlatna.
- Originalni zvučni džingl generisan u samoj aplikaciji pomoću Web Audio API-ja; ne koristi muziku iz pesme „Eye of the Tiger“.
- Vibracija i tresenje ekrana su opcioni i zavise od podrške uređaja/pregledača.
- Korisnikova fotografija je diskretni watermark; portretni okvir se pomera tokom proslave. Fotografija ne izvodi stvarne pokrete lica.
- Lokalno čuvanje podataka; bez naloga, reklama, analitike, praćenja i spoljnih skripti.

## Instalacija na Android telefonu

PWA mora biti dostupna preko **HTTPS** adrese (ili `localhost` za lokalno testiranje). Ovaj paket još nema javnu HTTPS adresu jer nije postavljen na hosting.

1. Raspakuj ZIP na računaru.
2. Objavi sadržaj foldera `sklek_king_pwa` na statičkom HTTPS hostingu (npr. Netlify ili GitHub Pages). Objavljuje se sadržaj foldera, ne ZIP kao jedna datoteka.
3. Otvori dobijenu HTTPS adresu u Google Chrome-u na Android telefonu.
4. Izaberi **Install app / Instaliraj aplikaciju** ili meni ⋮ → **Add to Home screen / Dodaj na početni ekran**.
5. Pokreni Sklek King sa nove ikone. Prvi put otvori aplikaciju dok si na internetu da se učitaju fajlovi za rad bez mreže.

Za Netlify Drop: prevuci raspakovani folder `sklek_king_pwa` na Netlify Drop stranicu. Hosting nalog može biti potreban za objavu i upravljanje adresom. Nakon objave, koristi HTTPS link koji hosting prikaže.

## Bezbednost i privatnost

- Nema registracije, lozinke, kontakata, lokacije, kamere ili mikrofona.
- Podaci se čuvaju u `localStorage` pregledača na tom uređaju/origin-u.
- Aplikacija ne šalje evidenciju na server i ne sadrži analitiku ili oglase.
- Service worker kešira samo datoteke ove aplikacije sa istog origin-a i ograničen je na njen scope.
- Uvoz prihvata samo JSON formata Sklek King v1, ograničen je na 1 MB i 10.000 datuma; proverava datume, brojeve, ciljeve i boje. Uvezeni sadržaj se ne izvršava.
- Izvoz rezervne kopije može sadržati tvoju evidenciju, ciljeve i podešavanja. Čuvaj ga privatno.
- Brisanje podataka iz Podešavanja briše lokalne rezultate i podešavanja. Pre toga napravi rezervnu kopiju ako želiš da sačuvaš evidenciju.
- Vibracija koristi standardni `navigator.vibrate()` API. PWA ne traži posebnu dozvolu; uređaj/pregledač može da je ne podrži ili da je sistemski utiša.

## Važna ograničenja

- Ovo je PWA paket spreman za HTTPS hosting, **nije Android APK i trenutno nema javni HTTPS link**. Potrebno je objaviti ga na hostingu da bi instalacija i deljenje linka radili na drugim telefonima.
- PWA ne može garantovati vibraciju na svakom Android uređaju. Web Share API zavisi od pregledača.
- Fotografija se animira kao portretni okvir (naginjanje, pomeranje ili kružno okretanje); ne menja se stvarni izraz lica. Mesečna proslava dodaje mali grafički efekat jezika.
- Zvuk je sintetički džingl koji se generiše na uređaju, bez spoljne audio datoteke.

## Podešavanja ciljeva i proslava

Početne vrednosti su 100 dnevno, 500 nedeljno i 2.000 mesečno. Promeni ih na početnoj strani. Proslava se beleži ključem odgovarajućeg perioda i prikazuje samo jednom po periodu. Povećanje cilja nakon već prikazane proslave neće ponovo pokrenuti proslavu u istom periodu; sledeći period dobija novu priliku.
