const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

let src = fs.readFileSync(path.join(__dirname, "..", "app.js"), "utf8");
src = src.replace(
  "saveState();renderAll();\n  if(newWins.length){celebrationQueue.push(...newWins);showNextCelebration();}",
  "saveState();\n  if(newWins.length){celebrationQueue.push(...newWins);globalThis.__wins = celebrationQueue.slice();}"
);
src = src.replace(
  "init();",
  "globalThis.__TEST__={isDateKey,mondayKey,periodBounds,sumFor,validateBackup,loadState,saveState,currentStreak,bestPeriod,periodToken,applyEntryChange,buildShareText,getState:()=>state,setState:v=>{state=v;}};"
);

const store = new Map();
const localStorage = {
  getItem: key => store.has(key) ? store.get(key) : null,
  setItem: (key, value) => store.set(key, value),
  removeItem: key => store.delete(key)
};
function makeContext() {
  const ctx = {
    console, Date, Intl, JSON, Math, Number, Object, Array, Set, Map, String,
    RegExp, Promise, Blob, URL, localStorage, window: {}, navigator: {}
  };
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(src, ctx);
  return ctx;
}
let ctx = makeContext();
let T = ctx.__TEST__;

assert(T.isDateKey("2026-11-09"));
assert(!T.isDateKey("2026-02-30"));
assert(!T.isDateKey("not-a-date"));
assert.equal(T.mondayKey("2026-11-09"), "2026-11-09");
assert.equal(T.mondayKey("2026-11-15"), "2026-11-09");
assert.equal(T.mondayKey("2026-11-16"), "2026-11-16");

const sample = {
  "2026-11-09": 10,
  "2026-11-10": 20,
  "2026-11-15": 5,
  "2026-10-31": 7
};
assert.equal(T.sumFor(sample, "daily", "2026-11-09"), 10);
assert.equal(T.sumFor(sample, "weekly", "2026-11-09"), 35);
assert.equal(T.sumFor(sample, "monthly", "2026-11-09"), 35);

const valid = {
  app: "Sklek King", version: 1, entries: {"2026-11-09": 55},
  goals: {daily: 5, weekly: 10, monthly: 15},
  settings: {accent: "#39e75f"}, celebrations: []
};
assert.equal(T.validateBackup(valid).entries["2026-11-09"], 55);
assert.throws(() => T.validateBackup({...valid, entries: {"2026-02-30": 4}}));
assert.throws(() => T.validateBackup({...valid, entries: {"2026-11-09": -1}}));
const tooMany = Object.fromEntries(Array.from({length: 10001}, (_, i) => {
  const d = new Date(2000, 0, 1 + i);
  return [d.toISOString().slice(0, 10), 1];
}));
assert.throws(() => T.validateBackup({...valid, entries: tooMany}));

let state = T.loadState();
state.entries = {"2026-11-09": 12};
T.setState(state);
T.saveState();
ctx = makeContext();
T = ctx.__TEST__;
assert.equal(T.getState().entries["2026-11-09"], 12);

const now = new Date();
const today = [
  now.getFullYear(),
  String(now.getMonth() + 1).padStart(2, "0"),
  String(now.getDate()).padStart(2, "0")
].join("-");
state = T.loadState();
state.entries = {};
state.goals = {daily: 5, weekly: 10, monthly: 15};
state.celebrations = [];
T.setState(state);
ctx.__wins = [];

let previous = {};
let next = {[today]: 5};
T.applyEntryChange(previous, next, today);
assert(ctx.__wins.includes("daily"));

previous = {...next};
next = {[today]: 10};
ctx.__wins = [];
T.applyEntryChange(previous, next, today);
assert(ctx.__wins.includes("weekly"));

previous = {...next};
next = {[today]: 15};
ctx.__wins = [];
T.applyEntryChange(previous, next, today);
assert(ctx.__wins.includes("monthly"));

previous = {...next};
next = {[today]: 20};
state = T.getState();
state.goals = {daily: 20, weekly: 20, monthly: 20};
T.setState(state);
ctx.__wins = [];
T.applyEntryChange(previous, next, today);
assert.equal(ctx.__wins.length, 0, "Proslava ne sme ponovo da se aktivira u istom periodu.");

console.log("PASS — datumi i ISO nedelje");
console.log("PASS — dnevni, nedeljni i mesečni zbir");
console.log("PASS — validacija rezervne kopije");
console.log("PASS — čuvanje i ponovno učitavanje lokalnih podataka");
console.log("PASS — dnevna, nedeljna i mesečna proslava samo jednom po periodu");
