package com.stepkingmini

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StepCounterService : Service(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private val prefs by lazy { getSharedPreferences("stepking", MODE_PRIVATE) }
    private val channelId = "stepking_steps"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH)
        } else startForeground(1, notification)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (sensor != null) sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_STEP_COUNTER) return
        val current = event.values[0].toLong()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val storedDay = prefs.getString("date", today)
        var stepsToday = prefs.getInt("today_steps", 0)
        if (storedDay != today) {
            if (storedDay != null) prefs.edit().putInt("day_$storedDay", stepsToday).apply()
            stepsToday = 0
            prefs.edit().putString("date", today).putInt("today_steps", 0).apply()
        }
        val hasLast = prefs.contains("last_sensor_total")
        val last = prefs.getLong("last_sensor_total", current)
        if (hasLast) {
            val delta = if (current >= last) current - last else current
            if (delta > 0 && delta < 1000) stepsToday += delta.toInt()
        }
        prefs.edit()
            .putLong("last_sensor_total", current)
            .putInt("today_steps", stepsToday)
            .apply()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotification(stepsToday))
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Step King brojač", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(steps: Int = prefs.getInt("today_steps", 0)): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("Step King Mini")
            .setContentText("$steps koraka danas")
            .setSmallIcon(android.R.drawable.ic_menu_directions)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
