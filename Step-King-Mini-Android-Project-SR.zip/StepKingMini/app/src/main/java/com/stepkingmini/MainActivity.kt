package com.stepkingmini

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 16, 14)
    private val panel = Color.rgb(24, 31, 27)
    private val green = Color.rgb(76, 220, 126)
    private lateinit var stepsText: TextView
    private lateinit var goalText: TextView
    private lateinit var kmText: TextView
    private lateinit var kcalText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var statusText: TextView
    private val prefs by lazy { getSharedPreferences("stepking", MODE_PRIVATE) }
    private val goal = 10000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refresh()
        requestNeededPermissions()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 34, 24, 28)
        }
        scroll.addView(layout)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "STEP KING MINI"
            textSize = 25f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        layout.addView(title)
        layout.addView(label("TVOJI DANAŠNJI KORACI", 14, Color.LTGRAY, true, 28))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 24, 18, 24)
            setBackgroundColor(panel)
        }
        layout.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        stepsText = label("0", 56, Color.WHITE, true, 0).apply { gravity = Gravity.CENTER }
        card.addView(stepsText)
        card.addView(label("KORAKA", 15, green, true, 0).apply { gravity = Gravity.CENTER })
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = goal
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.DKGRAY)
        }
        card.addView(progress, LinearLayout.LayoutParams(-1, 14).apply { topMargin = 22; bottomMargin = 10 })
        goalText = label("0% od cilja 10.000", 14, Color.LTGRAY, false, 0).apply { gravity = Gravity.CENTER }
        card.addView(goalText)

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        layout.addView(stats, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        kmText = statCard(stats, "0.00 km", "PREĐENA UDALJENOST")
        kcalText = statCard(stats, "0 kcal", "POTROŠENE KALORIJE")

        layout.addView(label("DNEVNI CILJ", 14, green, true, 26))
        layout.addView(label("10.000 koraka", 20, Color.WHITE, true, 5))
        statusText = label("Pokrećem brojač koraka…", 13, Color.LTGRAY, false, 18)
        layout.addView(statusText)

        val historyTitle = label("PREGLED POSLEDNJIH 7 DANA", 14, green, true, 28)
        layout.addView(historyTitle)
        val history = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(panel)
        }
        layout.addView(history, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        for (i in 0..6) {
            val day = System.currentTimeMillis() - i * 86400000L
            val key = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(day))
            val count = prefs.getInt("day_$key", if (i == 0) prefs.getInt("today_steps", 0) else 0)
            val row = TextView(this).apply {
                text = "${SimpleDateFormat("EEE, d MMM", Locale("sr", "RS")).format(Date(day))}     ${String.format("%,d", count)} koraka"
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(2, 9, 2, 9)
            }
            history.addView(row)
        }
        layout.addView(label("Tvoji rezultati čuvaju se na ovom telefonu.", 12, Color.GRAY, false, 20))
    }

    private fun statCard(parent: LinearLayout, value: String, caption: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 18)
            setBackgroundColor(panel)
        }
        parent.addView(box, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 6; marginStart = 6 })
        val v = label(value, 22, Color.WHITE, true, 0).apply { gravity = Gravity.CENTER }
        box.addView(v)
        box.addView(label(caption, 11, green, true, 6).apply { gravity = Gravity.CENTER })
        return v
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean, top: Int): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, top, 0, 0)
        }

    private fun requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 29 &&
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 10)
        } else startCounter()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCounter()
        else if (requestCode == 10) statusText.text = "Dozvoli pristup fizičkoj aktivnosti da bi brojanje radilo."
    }

    private fun startCounter() {
        val manager = getSystemService(SENSOR_SERVICE) as SensorManager
        if (manager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) == null) {
            statusText.text = "Ovaj telefon nema senzor za brojanje koraka."
            return
        }
        val intent = Intent(this, StepCounterService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            statusText.text = "Brojanje koraka je uključeno."
        } catch (_: Exception) {
            statusText.text = "Brojač nije pokrenut. Proveri dozvole."
        }
    }

    private fun refresh() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val savedDay = prefs.getString("date", today)
        if (savedDay != today) {
            prefs.edit().putString("date", today).putInt("today_steps", 0).apply()
        }
        val steps = prefs.getInt("today_steps", 0)
        stepsText.text = String.format("%,d", steps)
        progress.progress = steps.coerceAtMost(goal)
        goalText.text = "${(steps * 100 / goal).coerceAtMost(100)}% od cilja 10.000"
        kmText.text = String.format(Locale("sr", "RS"), "%.2f km", steps * 0.00075)
        kcalText.text = "${(steps * 0.04).toInt()} kcal"
    }
}
