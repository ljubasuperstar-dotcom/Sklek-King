# Step King Mini

Jednostavna Android aplikacija na srpskom jeziku (latinica) za brojanje koraka.

## Funkcije
- Brojanje pomoću ugrađenog Android senzora TYPE_STEP_COUNTER.
- Brojanje u pozadini kroz foreground service i stalno obaveštenje.
- Dnevni cilj od 10.000 koraka.
- Procena kilometara (750 m na 1.000 koraka) i kalorija (0,04 kcal po koraku).
- Pregled rezultata za poslednjih 7 dana.
- Čuvanje podataka lokalno na telefonu.
- Ponovno pokretanje brojača nakon restarta telefona.

## Izrada APK-a
U GitHub repozitorijumu otvori Actions, izaberi "Build Step King Mini APK",
klikni Run workflow, sačekaj da se završi, pa u Artifacts preuzmi
"Step-King-Mini-APK".

## Važne napomene
- Potreban je Android telefon sa senzorom koraka (STEP_COUNTER).
- Pri prvom pokretanju dozvoli fizičku aktivnost. Dozvola za obaveštenja
  omogućava prikaz stalnog statusa brojača.
- Android može ograničiti pozadinski rad zbog podešavanja baterije proizvođača.
  Ako brojanje staje, postavi bateriju aplikacije na Unrestricted / Unrestricted
  background usage.
- Kilometri i kalorije su procene; stvarne vrednosti zavise od dužine koraka,
  telesne mase i načina hoda.
- Prva verzija je osnovna; proveri rad na konkretnom telefonu pre oslanjanja
  na istoriju kao jedini zapis.
